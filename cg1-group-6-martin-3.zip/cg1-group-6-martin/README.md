# CG1-Demos


To run this demo you need nodejs installed. 
For best developing experience open the project in Visual Studio Code and install all recommended extensions.

Install dependencies:
```sh
/> npm i 
```

Run server from Terminal:
```sh
/> npm run dev
```

Run server from Visual Studio Code: Run the "Run Development Server" Task (optionally through the Task Runner extension).
