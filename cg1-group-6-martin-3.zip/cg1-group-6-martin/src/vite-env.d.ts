/// <reference types="vite/client" />


declare module '*.hdr' {
  const value: string
  export default value
}