
declare module '*.glb' {
    const value: string
    export default value
}

declare module '*.hdr' {
    const value: string
    export default value
}